from flask import Flask, request
import os
import requests
from dotenv import load_dotenv

load_dotenv()

TWILIO_AUTH_TOKEN = os.getenv("TWILIO_AUTH_TOKEN")
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")

app = Flask(__name__)

def send_to_telegram(text):
    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
    requests.get(url, params={"chat_id": CHAT_ID, "text": text})

@app.route("/sms", methods=["POST"])
def sms_webhook():
    from_number = request.form.get("From")
    body = request.form.get("Body")
    msg = f"📩 SMS from {from_number}:\n{body}"
    send_to_telegram(msg)
    return "OK", 200

@app.route("/")
def home():
    return "✅ Twilio SMS → Telegram Bot is running!"

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port)
